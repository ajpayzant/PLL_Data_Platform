# PLL Data Platform

Production Streamlit app and automated PLL data warehouse builder.

This repository is the GitHub-ready version of the working Colab/Streamlit PLL dashboard. The app reads a DuckDB warehouse from `data/analytics_database/pll_warehouse.duckdb`, and the scheduled GitHub Action refreshes the warehouse twice per week.

## Repository layout

```text
.
├── app.py                              # Streamlit app entrypoint
├── requirements.txt                    # Python dependencies
├── scripts/
│   └── build_warehouse.py              # PLL scrape + clean + marts + DuckDB builder
├── data/
│   ├── analytics_database/             # Generated DuckDB warehouse
│   ├── curated_data/all_requested_seasons/
│   └── source_data/
└── .github/workflows/update-pll-data.yml
```

## Local setup

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

Set the PLL bearer token as an environment variable:

```bash
export PLL_BEARER_TOKEN="Bearer YOUR_TOKEN_HERE"
```

Build or refresh the warehouse:

```bash
python scripts/build_warehouse.py
```

Run the app:

```bash
streamlit run app.py
```

## GitHub Actions automation

The workflow in `.github/workflows/update-pll-data.yml` runs:

- Sunday night at midnight Eastern time, implemented as Monday 00:00 `America/New_York`
- Friday morning at 8:00 AM `America/New_York`
- manually via **Actions → Update PLL Data Warehouse → Run workflow**

Add this repository secret before enabling automation:

```text
PLL_BEARER_TOKEN
```

The workflow builds the warehouse and commits changes under `data/` back to the repository.

## Streamlit Community Cloud deployment

Deploy `app.py` from the repository root. Streamlit Community Cloud will install `requirements.txt` and run the app from the GitHub repo.

If the app is deployed before the first data build, run the GitHub Action manually once so `data/analytics_database/pll_warehouse.duckdb` exists.

## Notes

- The app code intentionally preserves the current tested dashboard layout and behavior.
- The builder is adapted from the working Colab notebook and writes local repo-relative outputs instead of Google Drive outputs.
- The GitHub Action commits generated data. If the DuckDB file grows past GitHub's normal file-size limits, move the warehouse to a release asset, S3/R2, or another external data store.
